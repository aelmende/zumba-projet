<script type="text/x-template" id="wcs_templates_misc--loader">
	<div class="wcs-spinner"><div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect5"></div></div>
</script>
